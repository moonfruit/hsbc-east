CREATE OR REPLACE PROCEDURE "SP_EAST_GSCK_RESULT" (CORP_ID  IN VARCHAR, ORG_ID IN VARCHAR, RPT_DATE IN VARCHAR ) AS
   V_CORP_ID   VARCHAR(35);
   V_ORG_ID    VARCHAR(35);
   V_RPT_DATE VARCHAR(8);
   V_ZJJ NUMBER(22,6);
   V_ZZJFYE NUMBER(22,6);
   V_ZZDFYE NUMBER(22,6);
   V_ZZJD_AMT NUMBER(22,6);
   V_ZFCK_AMT NUMBER(22,6);
   V_TABLE_CN VARCHAR(100);
   V_RULE_ID VARCHAR(32);
   V_SUBJECT_NAME VARCHAR(100);
   V_CK_STATUS VARCHAR(100);
   V_KJRQ_DATE VARCHAR(8);
   V_CK_ITEMS VARCHAR(100);
   
--生成总分核对明细数据
BEGIN
    V_CORP_ID := CORP_ID;
    V_ORG_ID := ORG_ID;
    V_RPT_DATE := RPT_DATE;

    DELETE FROM PM_EAST_GSCK_RESULT WHERE ORG_ID=V_ORG_ID AND CJRQ_DATE=V_RPT_DATE;

    INSERT INTO PM_EAST_GSCK_RESULT(DATA_ID,DATA_DATE,CHECK_FLAG,ORG_ID,CJRQ_DATE,KMBH,FZJFYE,FZDFYE,FZJD_AMT,ZFCK_AMT,SUBJECT_NAME,CK_TABLES)
        select  ORG_ID||CJRQ_DATE||KMBH as "DATA_ID",  to_char(SYSDATE,'YYYYMMDD') as "DATA_DATE", CHECK_FLAG,
            ORG_ID,  CJRQ_DATE, KMBH,  FZJFYE,FZDFYE,FZJD_AMT,ZFCK_AMT,SUBJECT_NAME,CK_TABLES
            from  PM_EAST_GSCK_FZ 
            WHERE CJRQ_DATE=V_RPT_DATE AND ORG_ID=V_ORG_ID AND  BZ='BWB' AND CHECK_FLAG='F' 
            AND (ZFCK_AMT>0.1 OR ZFCK_AMT<-0.1) AND KMBH IS NOT NULL;
            
  
    DECLARE
        CURSOR CUR_REC IS select DATA_ID, ORG_ID, CJRQ_DATE,KMBH,RPT_NAME,FZJFYE,FZDFYE,CK_TABLES  from PM_EAST_GSCK_RESULT 
            WHERE CJRQ_DATE=V_RPT_DATE AND ORG_ID=V_ORG_ID;
    BEGIN
        FOR REC IN CUR_REC LOOP


            SELECT RULE_ID INTO V_RULE_ID FROM PM_EAST_GSCK_RESULT  WHERE ORG_ID=REC.ORG_ID AND CJRQ_DATE=V_RPT_DATE AND KMBH=REC.KMBH;
            V_TABLE_CN := null;
            V_CK_ITEMS:=null;
            IF REC.RPT_NAME LIKE '%GRDQCKFHZ%' THEN
                IF V_TABLE_CN IS NOT NULL THEN
                    V_TABLE_CN:=V_TABLE_CN||','||'个人定期存款分户账';
                ELSE
                    V_TABLE_CN:='个人定期存款分户账';
                END IF;

                IF V_RULE_ID IS NULL THEN
                    V_RULE_ID:='JHGZ00891';
                    V_CK_ITEMS:='存款余额与科目余额';
                END IF;
            END IF;
            IF REC.RPT_NAME LIKE '%GRHQCKFHZ%' THEN
                IF V_TABLE_CN IS NOT NULL THEN
                    V_TABLE_CN:=V_TABLE_CN||','||'个人活期存款分户账';
                ELSE
                    V_TABLE_CN:='个人活期存款分户账';
                END IF;

                IF V_RULE_ID IS NULL THEN
                    V_RULE_ID:='JHGZ00892';
                    V_CK_ITEMS:='存款余额与科目余额';
                END IF;

            END IF;
            IF REC.RPT_NAME LIKE '%DGDQCKFHZ%' THEN
                IF V_TABLE_CN IS NOT NULL THEN
                    V_TABLE_CN:=V_TABLE_CN||','||'对公定期存款分户账';
                ELSE
                    V_TABLE_CN:='对公定期存款分户账';
                END IF;

                IF V_RULE_ID IS NULL THEN
                    V_RULE_ID:='JHGZ00893';
                    V_CK_ITEMS:='存款余额与科目余额';
                END IF;

            END IF;
            IF REC.RPT_NAME LIKE '%DGHQCKFHZ%' THEN
                IF V_TABLE_CN IS NOT NULL THEN
                    V_TABLE_CN:=V_TABLE_CN||','||'对公活期存款分户账';
                ELSE
                    V_TABLE_CN:='对公活期存款分户账';
                END IF;

                IF V_RULE_ID IS NULL THEN
                    V_RULE_ID:='JHGZ00894';
                    V_CK_ITEMS:='存款余额与科目余额';
                END IF;

            END IF;
            IF REC.RPT_NAME LIKE '%NBFHZ%' THEN
                IF V_TABLE_CN IS NOT NULL THEN
                    V_TABLE_CN:=V_TABLE_CN||','||'内部分户账';
                ELSE
                    V_TABLE_CN:='内部分户账';
                END IF;

                IF V_RULE_ID IS  NULL THEN
                    V_RULE_ID:='JHGZ00895';
                    V_CK_ITEMS:='借方余额、贷方余额与科目余额';
                END IF;
            END IF;
            IF REC.RPT_NAME LIKE '%GRXDFHZ%' THEN
                IF V_TABLE_CN IS NOT NULL THEN
                    V_TABLE_CN:=V_TABLE_CN||','||'个人信贷分户账';
                ELSE
                    V_TABLE_CN:='个人信贷分户账';
                END IF;

                IF V_RULE_ID IS  NULL THEN
                   V_RULE_ID:='JHGZ00896';
                   V_CK_ITEMS:='正常本金、逾期本金与科目余额';
                END IF;

            END IF;
            IF REC.RPT_NAME='DGXDFHZ' THEN
                IF V_TABLE_CN IS NOT NULL THEN
                    V_TABLE_CN:=V_TABLE_CN||','||'对公信贷分户账';
                ELSE
                    V_TABLE_CN:='对公信贷分户账';
                END IF;

                IF V_RULE_ID IS  NULL THEN
                    V_RULE_ID:='JHGZ00897';
                    V_CK_ITEMS:='正常本金、逾期本金与科目余额';
                END IF;
            END IF;

            UPDATE PM_EAST_GSCK_RESULT  SET RULE_ID=V_RULE_ID, CK_ITEMS=V_CK_ITEMS, CK_TABLES_CN=V_TABLE_CN 
                WHERE CJRQ_DATE=V_RPT_DATE AND DATA_ID=REC.DATA_ID;

        END LOOP;
    END;

    COMMIT;
    --生成最终结果表
    DELETE FROM EAST_CBRC_S_CHECK_RESULT WHERE ORG_ID=V_ORG_ID AND CJRQ_DATE=V_RPT_DATE;
    --入总分校验规则结果表
    DECLARE
        CURSOR CUR_REC IS select DATA_ID, ORG_ID, CJRQ_DATE,KMBH,RULE_ID,FZJD_AMT,ZZJD_AMT,ZFCK_AMT,CK_ITEMS,CK_TABLES,CK_TABLES_CN, SUBJECT_NAME, CHECK_FLAG  
            from PM_EAST_GSCK_RESULT WHERE CJRQ_DATE=V_RPT_DATE AND ORG_ID=V_ORG_ID;
    BEGIN
        FOR REC IN CUR_REC LOOP
            V_CK_STATUS :=REC.CHECK_FLAG;

            INSERT INTO EAST_CBRC_S_CHECK_RESULT(DATA_ID,ORG_ID,RULE_ID,CJRQ_DATE,REPORT_NAME,CHECK_ITEM,SUBJECT_NAME,SUB_LEDGER,GENERAL_LEDGER,DIFF_VALUE,CHECK_STATUS)
                VALUES(REC.DATA_ID, REC.ORG_ID,REC.RULE_ID,REC.CJRQ_DATE,REC.CK_TABLES_CN,REC.CK_ITEMS,REC.SUBJECT_NAME,REC.FZJD_AMT,REC.ZZJD_AMT, REC.ZFCK_AMT, V_CK_STATUS);
        END LOOP;
    END;
    COMMIT;
END;